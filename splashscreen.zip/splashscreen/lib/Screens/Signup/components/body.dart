import 'package:flutter/material.dart';
import 'package:splashscreen/Screens/Login/login_screen.dart';
import 'package:splashscreen/Screens/Signup/components/background.dart';
import 'package:splashscreen/components/already_have_an_account_acheck.dart';
import 'package:splashscreen/components/rounded_button.dart';
import 'package:splashscreen/components/rounded_input_field.dart';
import 'package:splashscreen/components/rounded_password_field.dart';

class Body extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    Background(
      child: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              "SIGNUP",
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            SizedBox(height: size.height * 0.03),
            Image.asset(
              "assets/icons/signup.svg",
              height: size.height * 0.35,
            ),
            RoundedInputField(
              hintText: "Enter first name",
              onChanged: (value) {},
            ),
            RoundedInputField(
              hintText: "Enter last name",
              onChanged: (value) {},
            ),
            RoundedInputField(
              hintText: "Enter date of Birth",
              onChanged: (value) {},
            ),
            RoundedInputField(
              hintText: "Select Gender",
              onChanged: (value) {},
            ),
            RoundedInputField(
              hintText: "Select Blood Group",
              onChanged: (value) {},
            ),
            RoundedInputField(
              hintText: "Contact number",
              onChanged: (value) {},
            ),
            RoundedInputField(
              hintText: "Allergies",
              onChanged: (value) {},
            ),
            RoundedPasswordField(
              onChanged: (value) {},
            ),
            RoundedButton(
              text: "SIGNUP",
              press: () {},
            ),
            SizedBox(height: size.height * 0.03),
            AlreadyHaveAnAccountCheck(
              login: false,
              press: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) {
                      return LoginScreen();
                    },
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
    return Background;
  }
}
